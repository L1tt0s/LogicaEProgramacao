﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCalculadoraOperacoes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void btnSoma_Click(object sender, EventArgs e)
        {
            float varNum1 = float.Parse(txtNum1.Text);
            float varNum2 = float.Parse(txtNum2.Text);

            float varSoma = varNum1 + varNum2;

            MessageBox.Show("O resultado da soma é: " + varSoma);
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            float varNum1 = float.Parse(txtNum1.Text);
            float varNum2 = float.Parse(txtNum2.Text);

            float varSubtracao = varNum1 - varNum2;

            MessageBox.Show("O resultado da subtração é: " + varSubtracao);
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            float varNum1 = float.Parse(txtNum1.Text);
            float varNum2 = float.Parse(txtNum2.Text);

            float varMultiplicacao = varNum1 * varNum2;

            MessageBox.Show("O resultado da multiplicação é: " + varMultiplicacao);
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            float varNum1 = float.Parse(txtNum1.Text);
            float varNum2 = float.Parse(txtNum2.Text);

            float varDivisao = varNum1 / varNum2;

            MessageBox.Show("O resultado da divisão é: " + varDivisao);
        }
    }
}
