﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Victor_Lopes
{
    public partial class FrmExercicio04 : Form
    {
        public FrmExercicio04()
        {
            InitializeComponent();
        }

        private void FrmExercicio04_Load(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float varLado = float.Parse(txtLado.Text);
            float varArea = varLado * varLado;

            lblResultado.Text = varArea.ToString() + "m²";
        }
    }
}
