﻿namespace AppLista03_Victor_Lopes
{
    partial class FrmExercicio05
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlCabecalho = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblBase = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtAltura = new System.Windows.Forms.TextBox();
            this.lblAltura = new System.Windows.Forms.Label();
            this.txtBase = new System.Windows.Forms.TextBox();
            this.lblValorArea = new System.Windows.Forms.Label();
            this.lblValorPerimetro = new System.Windows.Forms.Label();
            this.lblResultadoArea = new System.Windows.Forms.Label();
            this.lblResultadoPerimetro = new System.Windows.Forms.Label();
            this.pnlCabecalho.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlCabecalho
            // 
            this.pnlCabecalho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.pnlCabecalho.Controls.Add(this.lblTitulo);
            this.pnlCabecalho.Location = new System.Drawing.Point(0, 0);
            this.pnlCabecalho.Name = "pnlCabecalho";
            this.pnlCabecalho.Size = new System.Drawing.Size(536, 87);
            this.pnlCabecalho.TabIndex = 16;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft YaHei", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(163)))), ((int)(((byte)(17)))));
            this.lblTitulo.Location = new System.Drawing.Point(31, 24);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(392, 46);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "SISTEMA RETANGULO";
            this.lblTitulo.Click += new System.EventHandler(this.lblTitulo_Click);
            // 
            // lblBase
            // 
            this.lblBase.AutoSize = true;
            this.lblBase.Font = new System.Drawing.Font("Microsoft YaHei", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBase.ForeColor = System.Drawing.Color.Black;
            this.lblBase.Location = new System.Drawing.Point(75, 114);
            this.lblBase.Name = "lblBase";
            this.lblBase.Size = new System.Drawing.Size(125, 23);
            this.lblBase.TabIndex = 11;
            this.lblBase.Text = "Valor da base:";
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(163)))), ((int)(((byte)(17)))));
            this.btnCalcular.Location = new System.Drawing.Point(206, 273);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(133, 36);
            this.btnCalcular.TabIndex = 15;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtAltura
            // 
            this.txtAltura.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.txtAltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAltura.Location = new System.Drawing.Point(206, 159);
            this.txtAltura.Name = "txtAltura";
            this.txtAltura.Size = new System.Drawing.Size(228, 27);
            this.txtAltura.TabIndex = 14;
            // 
            // lblAltura
            // 
            this.lblAltura.AutoSize = true;
            this.lblAltura.Font = new System.Drawing.Font("Microsoft YaHei", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAltura.ForeColor = System.Drawing.Color.Black;
            this.lblAltura.Location = new System.Drawing.Point(68, 159);
            this.lblAltura.Name = "lblAltura";
            this.lblAltura.Size = new System.Drawing.Size(132, 23);
            this.lblAltura.TabIndex = 13;
            this.lblAltura.Text = "Valor da altura:";
            // 
            // txtBase
            // 
            this.txtBase.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.txtBase.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBase.Location = new System.Drawing.Point(206, 114);
            this.txtBase.Name = "txtBase";
            this.txtBase.Size = new System.Drawing.Size(228, 27);
            this.txtBase.TabIndex = 12;
            // 
            // lblValorArea
            // 
            this.lblValorArea.AutoSize = true;
            this.lblValorArea.Font = new System.Drawing.Font("Microsoft YaHei", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorArea.ForeColor = System.Drawing.Color.Black;
            this.lblValorArea.Location = new System.Drawing.Point(69, 225);
            this.lblValorArea.Name = "lblValorArea";
            this.lblValorArea.Size = new System.Drawing.Size(121, 23);
            this.lblValorArea.TabIndex = 17;
            this.lblValorArea.Text = "Valor da área:";
            // 
            // lblValorPerimetro
            // 
            this.lblValorPerimetro.AutoSize = true;
            this.lblValorPerimetro.Font = new System.Drawing.Font("Microsoft YaHei", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorPerimetro.ForeColor = System.Drawing.Color.Black;
            this.lblValorPerimetro.Location = new System.Drawing.Point(243, 225);
            this.lblValorPerimetro.Name = "lblValorPerimetro";
            this.lblValorPerimetro.Size = new System.Drawing.Size(170, 23);
            this.lblValorPerimetro.TabIndex = 18;
            this.lblValorPerimetro.Text = "Valor do perímetro:";
            // 
            // lblResultadoArea
            // 
            this.lblResultadoArea.AutoSize = true;
            this.lblResultadoArea.Font = new System.Drawing.Font("Microsoft YaHei", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultadoArea.ForeColor = System.Drawing.Color.Black;
            this.lblResultadoArea.Location = new System.Drawing.Point(196, 225);
            this.lblResultadoArea.Name = "lblResultadoArea";
            this.lblResultadoArea.Size = new System.Drawing.Size(17, 23);
            this.lblResultadoArea.TabIndex = 19;
            this.lblResultadoArea.Text = "-";
            // 
            // lblResultadoPerimetro
            // 
            this.lblResultadoPerimetro.AutoSize = true;
            this.lblResultadoPerimetro.Font = new System.Drawing.Font("Microsoft YaHei", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultadoPerimetro.ForeColor = System.Drawing.Color.Black;
            this.lblResultadoPerimetro.Location = new System.Drawing.Point(419, 225);
            this.lblResultadoPerimetro.Name = "lblResultadoPerimetro";
            this.lblResultadoPerimetro.Size = new System.Drawing.Size(17, 23);
            this.lblResultadoPerimetro.TabIndex = 20;
            this.lblResultadoPerimetro.Text = "-";
            // 
            // FrmExercicio05
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(535, 367);
            this.Controls.Add(this.lblResultadoPerimetro);
            this.Controls.Add(this.lblResultadoArea);
            this.Controls.Add(this.lblValorPerimetro);
            this.Controls.Add(this.lblValorArea);
            this.Controls.Add(this.pnlCabecalho);
            this.Controls.Add(this.lblBase);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtAltura);
            this.Controls.Add(this.lblAltura);
            this.Controls.Add(this.txtBase);
            this.Name = "FrmExercicio05";
            this.Text = "FrmExercicio05";
            this.pnlCabecalho.ResumeLayout(false);
            this.pnlCabecalho.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlCabecalho;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblBase;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.TextBox txtAltura;
        private System.Windows.Forms.Label lblAltura;
        private System.Windows.Forms.TextBox txtBase;
        private System.Windows.Forms.Label lblValorArea;
        private System.Windows.Forms.Label lblValorPerimetro;
        private System.Windows.Forms.Label lblResultadoArea;
        private System.Windows.Forms.Label lblResultadoPerimetro;
    }
}