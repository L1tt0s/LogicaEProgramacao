﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Victor_Lopes
{
    public partial class FrmExercicio05 : Form
    {
        public FrmExercicio05()
        {
            InitializeComponent();
        }

        private void lblTitulo_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float varBase = float.Parse(txtBase.Text);
            float varAltura = float.Parse(txtAltura.Text);

            float varArea = varBase * varAltura;
            float varPerimetro = varAltura * 2 + varBase * 2;

            lblResultadoArea.Text = varArea.ToString();
            lblResultadoPerimetro.Text = varPerimetro.ToString();
        }
    }
}
