﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Victor_Lopes
{
    public partial class FrmExercicio02 : Form
    {
        public FrmExercicio02()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float varGasolina = float.Parse(txtGasolina.Text);
            float varPago = float.Parse(txtValorPago.Text);

            float varLitros = varPago / varGasolina;

            MessageBox.Show("O usuário conseguiu abastecer " + varLitros + " litros no total!");
        }

        private void FrmExercicio02_Load(object sender, EventArgs e)
        {

        }

        private void FrmExercicio02_Load_1(object sender, EventArgs e)
        {

        }

        private void lblTitulo_Click(object sender, EventArgs e)
        {

        }

        private void txtGasolina_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
